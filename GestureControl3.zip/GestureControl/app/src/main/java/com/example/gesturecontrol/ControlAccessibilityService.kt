package com.example.gesturecontrol

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast

/**
 * The "hands" of the app: injects taps and swipes system-wide, presses Back / Home,
 * and owns the cursor overlay. Enabled by the user in Settings > Accessibility.
 */
class ControlAccessibilityService : AccessibilityService() {

    companion object {
        /** Shows a small on-screen message for every tap / swipe / Back / Home attempt. */
        const val DEBUG_TOASTS = true

        @Volatile
        var instance: ControlAccessibilityService? = null
            private set
    }

    private val main = Handler(Looper.getMainLooper())
    private var overlay: CursorOverlay? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit

    override fun onInterrupt() = Unit

    override fun onUnbind(intent: Intent?): Boolean {
        endSession()
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    // ---------------------------------------------------------------- cursor

    fun showCursor(x: Float, y: Float, mode: CursorMode) {
        main.post {
            val o = overlay ?: CursorOverlay(this).also {
                it.attach()
                overlay = it
            }
            o.update(x, y, mode)
        }
    }

    fun hideCursor() {
        main.post { overlay?.hideCursor() }
    }

    /** Removes the cursor overlay completely (called when hand tracking stops). */
    fun endSession() {
        main.post {
            overlay?.detach()
            overlay = null
        }
    }

    // ---------------------------------------------------------------- actions

    fun tap(x: Float, y: Float, longPress: Boolean) {
        main.post {
            val (w, h) = ScreenInfo.size(this)
            val path = Path().apply { moveTo(x.coerceIn(1f, w - 1f), y.coerceIn(1f, h - 1f)) }
            dispatch(path, if (longPress) 700L else 50L, if (longPress) "Long press" else "Tap")
        }
    }

    fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long) {
        main.post {
            val (w, h) = ScreenInfo.size(this)
            val path = Path().apply {
                moveTo(x1.coerceIn(1f, w - 1f), y1.coerceIn(1f, h - 1f))
                lineTo(x2.coerceIn(1f, w - 1f), y2.coerceIn(1f, h - 1f))
            }
            dispatch(path, durationMs, "Swipe")
        }
    }

    fun back() {
        main.post {
            val ok = performGlobalAction(GLOBAL_ACTION_BACK)
            debug("Back: " + if (ok) "OK" else "REFUSED by phone")
        }
    }

    fun home() {
        main.post {
            val ok = performGlobalAction(GLOBAL_ACTION_HOME)
            debug("Home: " + if (ok) "OK" else "REFUSED by phone")
        }
    }

    private fun dispatch(path: Path, durationMs: Long, label: String) {
        val stroke = GestureDescription.StrokeDescription(path, 0L, durationMs.coerceAtLeast(1L))
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        val callback = object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                debug("$label: sent OK")
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                debug("$label: cancelled by phone")
            }
        }
        val accepted = dispatchGesture(gesture, callback, null)
        if (!accepted) debug("$label: REFUSED by phone")
    }

    private fun debug(message: String) {
        if (DEBUG_TOASTS) Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}
