package com.example.gesturecontrol

import android.content.Context

/** Settings the user can change live from the app screen (saved on the phone). */
object Tuning {
    /** 1..10. Higher = the cursor travels farther for the same hand movement. */
    @Volatile
    var sensitivity = 7

    /** 1..10. Higher = steadier cursor, but slower to follow your hand. */
    @Volatile
    var smoothing = 3

    private const val PREFS = "tuning"

    fun load(context: Context) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        sensitivity = prefs.getInt("sensitivity", 7).coerceIn(1, 10)
        smoothing = prefs.getInt("smoothing", 3).coerceIn(1, 10)
    }

    fun save(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putInt("sensitivity", sensitivity)
            .putInt("smoothing", smoothing)
            .apply()
    }
}
