package com.example.gesturecontrol

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Matrix
import android.os.SystemClock
import android.util.Log
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarkerResult
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Foreground service: front camera -> MediaPipe hand landmarks -> [GestureEngine] ->
 * [ControlAccessibilityService]. A foreground service (type camera) is what lets the
 * camera keep running while other apps are on screen.
 */
class GestureService : LifecycleService(), GestureListener {

    companion object {
        const val ACTION_STOP = "com.example.gesturecontrol.STOP"
        @Volatile
        var running = false
            private set

        private const val TAG = "GestureService"
        private const val CHANNEL_ID = "gesture_control"
        private const val NOTIFICATION_ID = 1
        private const val MODEL_FILE = "hand_landmarker.task"
    }

    private lateinit var analysisExecutor: ExecutorService
    private var handLandmarker: HandLandmarker? = null
    private var cameraProvider: ProcessCameraProvider? = null
    private var engine: GestureEngine? = null

    private var bitmapBuffer: Bitmap? = null
    private var lastTimestamp = 0L
    @Volatile private var lastAspect = 0.75f

    override fun onCreate() {
        super.onCreate()
        Tuning.load(applicationContext)
        analysisExecutor = Executors.newSingleThreadExecutor()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        startInForeground()
        if (!running) {
            running = true
            engine = GestureEngine(this)
            try {
                createLandmarker()
                startCamera()
            } catch (e: Exception) {
                Log.e(TAG, "Could not start hand tracking", e)
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        running = false
        cameraProvider?.unbindAll()
        analysisExecutor.shutdown()
        handLandmarker?.close()
        handLandmarker = null
        ControlAccessibilityService.instance?.endSession()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- setup

    private fun startInForeground() {
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Gesture control", NotificationManager.IMPORTANCE_LOW)
        )
        val stop = PendingIntent.getService(
            this, 0,
            Intent(this, GestureService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val open = PendingIntent.getActivity(
            this, 1,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentTitle("Hand control is on")
            .setContentText("The front camera is tracking your hand")
            .setContentIntent(open)
            .addAction(0, "Stop", stop)
            .setOngoing(true)
            .build()
        ServiceCompat.startForeground(
            this, NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
        )
    }

    private fun createLandmarker() {
        val base = BaseOptions.builder().setModelAssetPath(MODEL_FILE).build()
        val options = HandLandmarker.HandLandmarkerOptions.builder()
            .setBaseOptions(base)
            .setNumHands(1)
            .setMinHandDetectionConfidence(0.5f)
            .setMinHandPresenceConfidence(0.5f)
            .setMinTrackingConfidence(0.5f)
            .setRunningMode(RunningMode.LIVE_STREAM)
            .setResultListener { result, _ -> handleResult(result) }
            .setErrorListener { error -> Log.e(TAG, "MediaPipe error", error) }
            .build()
        handLandmarker = HandLandmarker.createFromOptions(this, options)
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            cameraProvider = provider

            val analysis = ImageAnalysis.Builder()
                .setResolutionSelector(
                    ResolutionSelector.Builder()
                        .setAspectRatioStrategy(AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY)
                        .build()
                )
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                .build()
            analysis.setAnalyzer(analysisExecutor) { image -> analyze(image) }

            provider.unbindAll()
            provider.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, analysis)
        }, ContextCompat.getMainExecutor(this))
    }

    // ---------------------------------------------------------------- per frame

    private fun analyze(image: ImageProxy) {
        val landmarker = handLandmarker
        if (landmarker == null) {
            image.close()
            return
        }
        val width = image.width
        val height = image.height
        val rotation = image.imageInfo.rotationDegrees

        val buffer = bitmapBuffer?.takeIf { it.width == width && it.height == height }
            ?: Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888).also { bitmapBuffer = it }
        image.use { buffer.copyPixelsFromBuffer(it.planes[0].buffer) }

        // Rotate to upright, then mirror like a selfie so "my right" is the right side of the image.
        val matrix = Matrix().apply {
            postRotate(rotation.toFloat())
            postScale(-1f, 1f)
        }
        val upright = Bitmap.createBitmap(buffer, 0, 0, width, height, matrix, true)
        lastAspect = upright.width.toFloat() / upright.height

        val now = SystemClock.uptimeMillis()
        lastTimestamp = if (now > lastTimestamp) now else lastTimestamp + 1
        landmarker.detectAsync(BitmapImageBuilder(upright).build(), lastTimestamp)
    }

    /** Runs on MediaPipe's result thread, one call per analysed frame. */
    private fun handleResult(result: HandLandmarkerResult) {
        val engine = engine ?: return
        val (w, h) = ScreenInfo.size(this)
        engine.screenW = w
        engine.screenH = h

        val hand = result.landmarks().firstOrNull()
        val points = hand?.map { Pt(it.x(), it.y()) }
        engine.onFrame(points, lastAspect, SystemClock.uptimeMillis())
    }

    // ---------------------------------------------------------------- GestureListener

    override fun onCursor(x: Float, y: Float, mode: CursorMode) {
        ControlAccessibilityService.instance?.showCursor(x, y, mode)
    }

    override fun onCursorHidden() {
        ControlAccessibilityService.instance?.hideCursor()
    }

    override fun onTap(x: Float, y: Float, longPress: Boolean) {
        ControlAccessibilityService.instance?.tap(x, y, longPress)
    }

    override fun onSwipe(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long) {
        ControlAccessibilityService.instance?.swipe(x1, y1, x2, y2, durationMs)
    }

    override fun onBack() {
        ControlAccessibilityService.instance?.back()
    }

    override fun onHome() {
        ControlAccessibilityService.instance?.home()
    }
}
