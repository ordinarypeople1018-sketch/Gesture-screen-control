package com.example.gesturecontrol

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var statusText: TextView
    private lateinit var accessibilityButton: Button
    private lateinit var toggleButton: Button

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            if (isGranted(Manifest.permission.CAMERA)) {
                launchService()
            } else {
                Toast.makeText(this, R.string.camera_denied, Toast.LENGTH_LONG).show()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        Tuning.load(this)

        statusText = findViewById(R.id.statusText)
        accessibilityButton = findViewById(R.id.accessibilityButton)
        toggleButton = findViewById(R.id.toggleButton)

        accessibilityButton.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        toggleButton.setOnClickListener { button ->
            if (GestureService.running) {
                stopService(Intent(this, GestureService::class.java))
            } else if (ControlAccessibilityService.instance == null) {
                Toast.makeText(
                    this,
                    "Turn on the Gesture Control accessibility service first",
                    Toast.LENGTH_LONG
                ).show()
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            } else {
                requestPermissionsThenStart()
            }
            button.postDelayed({ refresh() }, 400)
        }

        bindSlider(
            findViewById(R.id.sensitivitySeek),
            findViewById(R.id.sensitivityLabel),
            { "Cursor speed: $it / 10  (higher = faster)" },
            { Tuning.sensitivity },
            { Tuning.sensitivity = it }
        )
        bindSlider(
            findViewById(R.id.smoothingSeek),
            findViewById(R.id.smoothingLabel),
            { "Smoothness: $it / 10  (higher = steadier but slower)" },
            { Tuning.smoothing },
            { Tuning.smoothing = it }
        )
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    /** A 1..10 slider that updates [Tuning] live, even while hand control is running. */
    private fun bindSlider(
        seek: SeekBar,
        label: TextView,
        describe: (Int) -> String,
        getValue: () -> Int,
        setValue: (Int) -> Unit
    ) {
        seek.max = 9
        seek.progress = getValue() - 1
        label.text = describe(getValue())
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) {
                setValue(progress + 1)
                label.text = describe(progress + 1)
            }

            override fun onStartTrackingTouch(bar: SeekBar?) = Unit

            override fun onStopTrackingTouch(bar: SeekBar?) {
                Tuning.save(this@MainActivity)
            }
        })
    }

    private fun refresh() {
        val accessibilityOn = ControlAccessibilityService.instance != null
        val running = GestureService.running
        statusText.text = buildString {
            append("Accessibility service: ").append(if (accessibilityOn) "ON" else "OFF").append('\n')
            append("Hand tracking: ").append(if (running) "RUNNING" else "STOPPED")
        }
        toggleButton.text = if (running) "Stop hand control" else "2. Start hand control"
    }

    private fun isGranted(permission: String) =
        ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED

    private fun requestPermissionsThenStart() {
        val missing = mutableListOf<String>()
        if (!isGranted(Manifest.permission.CAMERA)) missing += Manifest.permission.CAMERA
        if (Build.VERSION.SDK_INT >= 33 && !isGranted(Manifest.permission.POST_NOTIFICATIONS)) {
            missing += Manifest.permission.POST_NOTIFICATIONS
        }
        if (missing.isEmpty()) launchService() else permissionLauncher.launch(missing.toTypedArray())
    }

    private fun launchService() {
        ContextCompat.startForegroundService(this, Intent(this, GestureService::class.java))
        toggleButton.postDelayed({ refresh() }, 400)
    }
}
