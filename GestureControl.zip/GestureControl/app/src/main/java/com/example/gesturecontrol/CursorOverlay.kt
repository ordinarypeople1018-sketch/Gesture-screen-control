package com.example.gesturecontrol

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.os.Build
import android.view.View
import android.view.WindowManager

/**
 * A full-screen, touch-transparent overlay that draws the on-screen hand cursor.
 * Must be created with the AccessibilityService as its context (TYPE_ACCESSIBILITY_OVERLAY).
 */
class CursorOverlay(context: Context) {

    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val view = CursorView(context)
    private var attached = false

    fun attach() {
        if (attached) return
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        if (Build.VERSION.SDK_INT >= 28) {
            params.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        windowManager.addView(view, params)
        attached = true
    }

    fun detach() {
        if (!attached) return
        windowManager.removeView(view)
        attached = false
    }

    fun update(x: Float, y: Float, mode: CursorMode) {
        view.set(x, y, mode, true)
    }

    fun hideCursor() {
        view.set(0f, 0f, CursorMode.REST, false)
    }

    private class CursorView(context: Context) : View(context) {
        private var cx = 0f
        private var cy = 0f
        private var mode = CursorMode.REST
        private var visible = false
        private val density = context.resources.displayMetrics.density

        private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
        private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = Color.WHITE
            strokeWidth = 3f * density
        }

        fun set(x: Float, y: Float, newMode: CursorMode, show: Boolean) {
            cx = x
            cy = y
            mode = newMode
            visible = show
            invalidate()
        }

        override fun onDraw(canvas: Canvas) {
            if (!visible) return
            val radius = (if (mode == CursorMode.PRESS) 14f else 22f) * density
            fill.color = when (mode) {
                CursorMode.MOVE -> Color.argb(150, 33, 150, 243)   // blue
                CursorMode.PRESS -> Color.argb(210, 244, 67, 54)   // red
                CursorMode.SCROLL -> Color.argb(150, 76, 175, 80)  // green
                CursorMode.HOLD -> Color.argb(170, 255, 152, 0)    // orange
                CursorMode.REST -> Color.argb(70, 158, 158, 158)   // grey
            }
            canvas.drawCircle(cx, cy, radius, fill)
            canvas.drawCircle(cx, cy, radius, ring)
        }
    }
}
