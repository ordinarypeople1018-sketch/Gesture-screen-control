package com.example.gesturecontrol

import android.content.Context
import android.hardware.display.DisplayManager
import android.util.DisplayMetrics
import android.view.Display

object ScreenInfo {
    /** Full physical screen size in pixels for the current rotation (width, height). */
    @Suppress("DEPRECATION")
    fun size(context: Context): Pair<Float, Float> {
        val metrics = DisplayMetrics()
        val manager = context.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        manager.getDisplay(Display.DEFAULT_DISPLAY).getRealMetrics(metrics)
        return metrics.widthPixels.toFloat() to metrics.heightPixels.toFloat()
    }
}
