package com.example.gesturecontrol

import kotlin.math.abs
import kotlin.math.hypot

/** A hand landmark in normalized image coordinates (0..1), already upright and mirrored. */
data class Pt(val x: Float, val y: Float)

enum class CursorMode { MOVE, PRESS, SCROLL, HOLD, REST }

enum class Pose { NONE, POINT, PINCH, SCROLL, THREE, FIST, OPEN }

/** Everything the engine wants the phone to do. Coordinates are screen pixels. */
interface GestureListener {
    fun onCursor(x: Float, y: Float, mode: CursorMode)
    fun onCursorHidden()
    fun onTap(x: Float, y: Float, longPress: Boolean)
    fun onSwipe(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long)
    fun onBack()
    fun onHome()
}

/**
 * Turns the 21 MediaPipe hand landmarks of each camera frame into phone actions.
 *
 * Landmark indices: 0 wrist, 4 thumb tip, 5 index knuckle, 6 index middle joint, 8 index tip,
 * 9 middle knuckle, 10/12 middle joint/tip, 14/16 ring joint/tip, 18/20 pinky joint/tip.
 *
 * Call [onFrame] from a single thread only.
 */
class GestureEngine(private val listener: GestureListener) {

    @Volatile var screenW = 1080f
    @Volatile var screenH = 2400f

    companion object {
        // Part of the camera view that maps onto the whole screen (mirrored, upright image).
        // Smaller region = less hand travel needed, but more sensitive.
        const val REGION_X_MIN = 0.15f
        const val REGION_X_MAX = 0.85f
        const val REGION_Y_MIN = 0.15f
        const val REGION_Y_MAX = 0.75f

        const val ANCHOR = 5               // index knuckle: stays put while you pinch
        const val STABLE_FRAMES = 2        // frames a pose must persist before it counts

        const val PINCH_START = 0.25f      // thumb-index gap / hand size to start a pinch
        const val PINCH_RELEASE = 0.40f    // gap to end a pinch (hysteresis)
        const val PINCH_MIN_REACH = 0.75f  // index tip must be away from the palm (rules out a fist)
        const val FINGER_EXTENDED = 1.15f  // tip-to-wrist vs joint-to-wrist ratio

        const val DRAG_THRESHOLD = 0.07f   // fraction of screen width before a pinch becomes a drag
        const val LONG_PRESS_MS = 600L
        const val HOLD_MS = 1000L          // fist / three fingers hold time

        const val SCROLL_STEP_Y = 0.10f    // hand travel (fraction of screen height) per scroll swipe
        const val SCROLL_STEP_X = 0.15f
        const val SCROLL_COOLDOWN_MS = 350L
        const val INVERT_SCROLL = false    // true = hand up scrolls the content back up

        const val LOST_GRACE_MS = 250L     // tolerate brief tracking dropouts
    }

    private var pose = Pose.NONE
    private var candidate = Pose.NONE
    private var candidateCount = 0

    private var hasPos = false
    private var sx = 0f
    private var sy = 0f
    private var lastSeenMs = 0L

    private var pinchStartX = 0f
    private var pinchStartY = 0f
    private var pinchStartMs = 0L
    private var pinchLastX = 0f
    private var pinchLastY = 0f
    private var dragging = false

    private var scrollAnchorX = 0f
    private var scrollAnchorY = 0f
    private var lastScrollMs = 0L

    private var holdStartMs = 0L
    private var holdFired = false

    /** [lm] is null when no hand is visible. [aspect] is image width / height. */
    fun onFrame(lm: List<Pt>?, aspect: Float, now: Long) {
        if (lm == null || lm.size < 21) {
            handleLost(now)
            return
        }
        lastSeenMs = now

        updatePosition(lm[ANCHOR])
        val raw = classify(lm, aspect)
        val next = stabilize(raw)
        if (next != pose) {
            exitPose(pose, now)
            pose = next
            enterPose(pose, now)
        }

        when (pose) {
            Pose.POINT -> listener.onCursor(sx, sy, CursorMode.MOVE)
            Pose.PINCH -> handlePinch(raw == Pose.PINCH)
            Pose.SCROLL -> handleScroll(now)
            Pose.FIST -> handleHold(now) { listener.onBack() }
            Pose.THREE -> handleHold(now) { listener.onHome() }
            Pose.OPEN, Pose.NONE -> listener.onCursor(sx, sy, CursorMode.REST)
        }
    }

    // ---------------------------------------------------------------- position

    private fun norm(v: Float, lo: Float, hi: Float) = ((v - lo) / (hi - lo)).coerceIn(0f, 1f)

    private fun updatePosition(a: Pt) {
        val mx = norm(a.x, REGION_X_MIN, REGION_X_MAX) * screenW
        val my = norm(a.y, REGION_Y_MIN, REGION_Y_MAX) * screenH
        if (!hasPos) {
            sx = mx; sy = my; hasPos = true
            return
        }
        // Adaptive smoothing: heavy when the hand is nearly still, light when it moves fast.
        val dist = hypot(mx - sx, my - sy)
        val alpha = (0.15f + dist / (screenW * 0.3f)).coerceIn(0.15f, 0.85f)
        sx += (mx - sx) * alpha
        sy += (my - sy) * alpha
    }

    // ---------------------------------------------------------------- classification

    private fun dist(a: Pt, b: Pt, aspect: Float) = hypot((a.x - b.x) * aspect, a.y - b.y)

    private fun classify(lm: List<Pt>, aspect: Float): Pose {
        val wrist = lm[0]
        val size = dist(wrist, lm[9], aspect).coerceAtLeast(1e-4f)

        fun extended(tip: Int, joint: Int) =
            dist(lm[tip], wrist, aspect) > dist(lm[joint], wrist, aspect) * FINGER_EXTENDED

        val index = extended(8, 6)
        val middle = extended(12, 10)
        val ring = extended(16, 14)
        val pinky = extended(20, 18)

        val palm = Pt(
            (lm[0].x + lm[5].x + lm[9].x + lm[13].x + lm[17].x) / 5f,
            (lm[0].y + lm[5].y + lm[9].y + lm[13].y + lm[17].y) / 5f
        )
        val pinchGap = dist(lm[4], lm[8], aspect) / size
        val indexReach = dist(lm[8], palm, aspect) / size
        val pinchLimit = if (pose == Pose.PINCH) PINCH_RELEASE else PINCH_START
        if (pinchGap < pinchLimit && indexReach > PINCH_MIN_REACH) return Pose.PINCH

        return when {
            index && middle && ring && pinky -> Pose.OPEN
            index && middle && ring && !pinky -> Pose.THREE
            index && middle && !ring && !pinky -> Pose.SCROLL
            index && !middle && !ring && !pinky -> Pose.POINT
            !index && !middle && !ring && !pinky -> Pose.FIST
            else -> Pose.NONE
        }
    }

    /** A new pose only counts after it has been seen for [STABLE_FRAMES] frames in a row. */
    private fun stabilize(raw: Pose): Pose {
        if (raw == pose) {
            candidate = raw
            candidateCount = 0
            return pose
        }
        if (raw == candidate) candidateCount++ else {
            candidate = raw
            candidateCount = 1
        }
        return if (candidateCount >= STABLE_FRAMES) candidate else pose
    }

    // ---------------------------------------------------------------- pose transitions

    private fun enterPose(p: Pose, now: Long) {
        when (p) {
            Pose.PINCH -> {
                pinchStartX = sx; pinchStartY = sy
                pinchLastX = sx; pinchLastY = sy
                pinchStartMs = now
                dragging = false
            }
            Pose.SCROLL -> {
                scrollAnchorX = sx; scrollAnchorY = sy
                lastScrollMs = now
            }
            Pose.FIST, Pose.THREE -> {
                holdStartMs = now
                holdFired = false
            }
            else -> Unit
        }
    }

    private fun exitPose(p: Pose, now: Long) {
        if (p != Pose.PINCH) return
        val heldMs = now - pinchStartMs
        if (dragging) {
            listener.onSwipe(pinchStartX, pinchStartY, pinchLastX, pinchLastY, heldMs.coerceIn(120L, 600L))
        } else {
            listener.onTap(pinchStartX, pinchStartY, heldMs >= LONG_PRESS_MS)
        }
        dragging = false
    }

    // ---------------------------------------------------------------- per-pose behaviour

    private fun handlePinch(live: Boolean) {
        if (!dragging && hypot(sx - pinchStartX, sy - pinchStartY) > screenW * DRAG_THRESHOLD) {
            dragging = true
        }
        // Until it turns into a drag the cursor stays frozen where the pinch began,
        // so closing your fingers cannot nudge the tap off target.
        val x = if (dragging) sx else pinchStartX
        val y = if (dragging) sy else pinchStartY
        if (live) {
            pinchLastX = x
            pinchLastY = y
        }
        listener.onCursor(x, y, CursorMode.PRESS)
    }

    private fun handleScroll(now: Long) {
        listener.onCursor(sx, sy, CursorMode.SCROLL)
        if (now - lastScrollMs < SCROLL_COOLDOWN_MS) return

        val dx = sx - scrollAnchorX
        val dy = sy - scrollAnchorY
        val cx = screenW / 2f
        val cy = screenH / 2f
        val sign = if (INVERT_SCROLL) -1f else 1f

        if (abs(dy) >= screenH * SCROLL_STEP_Y && abs(dy) >= abs(dx)) {
            val dir = (if (dy < 0) -1f else 1f) * sign
            val half = screenH * 0.2f
            listener.onSwipe(cx, cy - dir * half, cx, cy + dir * half, 250L)
            scrollAnchorX = sx; scrollAnchorY = sy; lastScrollMs = now
        } else if (abs(dx) >= screenW * SCROLL_STEP_X && abs(dx) > abs(dy)) {
            val dir = (if (dx < 0) -1f else 1f) * sign
            val half = screenW * 0.3f
            listener.onSwipe(cx - dir * half, cy, cx + dir * half, cy, 250L)
            scrollAnchorX = sx; scrollAnchorY = sy; lastScrollMs = now
        }
    }

    private fun handleHold(now: Long, action: () -> Unit) {
        listener.onCursor(sx, sy, CursorMode.HOLD)
        if (!holdFired && now - holdStartMs >= HOLD_MS) {
            holdFired = true
            action()
        }
    }

    private fun handleLost(now: Long) {
        if (now - lastSeenMs < LOST_GRACE_MS) return
        if (hasPos || pose != Pose.NONE) {
            // A pinch that is interrupted by losing the hand is cancelled, never turned into a tap.
            pose = Pose.NONE
            candidate = Pose.NONE
            candidateCount = 0
            dragging = false
            hasPos = false
            listener.onCursorHidden()
        }
    }
}
