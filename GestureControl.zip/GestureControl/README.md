# Gesture Control (Android)

Control your whole phone with hand gestures while it stands in front of you.
The front camera tracks your hand (Google MediaPipe), and an Accessibility Service
turns what it sees into real taps, swipes, Back and Home, in any app.

## Build and install

1. Install **Android Studio** (Koala or newer) and open the `GestureControl` folder.
2. Let Gradle sync. On the first build it downloads the hand model
   (`hand_landmarker.task`, about 8 MB) into `app/src/main/assets/`.
   If your build machine has no internet, download it yourself from
   `https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/latest/hand_landmarker.task`
   and put it at `app/src/main/assets/hand_landmarker.task`.
3. Plug in your phone (USB debugging on) and press **Run**.

Requires Android 8.0+ (API 26) and a front camera.

## First-time setup on the phone

1. Open the app and tap **Open accessibility settings**. Find **Gesture Control**
   (under "Installed apps" or "Downloaded apps") and switch it on.
   - Android 13+ may grey it out for apps installed outside the Play Store. Fix: Settings > Apps >
     Gesture Control > three-dot menu > **Allow restricted settings**, then try again.
2. Back in the app tap **Start hand control** and allow the camera.
3. Put the phone on its stand and keep your hand about 30-50 cm from the camera, fully in view.

A coloured circle on the screen shows where your hand is pointing.
Stop any time with the notification's **Stop** button or the button in the app.

## Gestures

| Gesture | What it does | Cursor colour |
|---|---|---|
| Index finger up, other fingers curled, move hand | Move the cursor | blue |
| Pinch thumb + index, then release | Tap | red |
| Pinch and hold still for 0.6 s, release | Long press | red |
| Pinch, move, release | Swipe / drag from where you pinched to where you released | red |
| Two fingers up (index + middle), move hand up / down / left / right | Scroll or swipe in that direction (repeats while you keep moving) | green |
| Fist, hold 1 s | Back | orange |
| Three fingers up (index, middle, ring), hold 1 s | Home | orange |
| Open palm | Rest: nothing happens | grey |

Tips: pause with an open palm when you are not using it. If the hand disappears from view
the cursor hides, and a pinch in progress is cancelled rather than turned into a tap.

## Tuning

Everything lives in the `companion object` at the top of
`app/src/main/java/com/example/gesturecontrol/GestureEngine.kt`:

| Setting | Effect |
|---|---|
| `REGION_X_MIN/MAX`, `REGION_Y_MIN/MAX` | Part of the camera view mapped to the full screen. Shrink it if you have to reach too far; widen it if the cursor feels twitchy. |
| `PINCH_START`, `PINCH_RELEASE` | How close thumb and index must be to pinch, and how far apart to let go. |
| `HOLD_MS` | Hold time for Back / Home. |
| `LONG_PRESS_MS`, `DRAG_THRESHOLD` | Long-press time, and how far you move before a pinch becomes a drag. |
| `SCROLL_STEP_Y/X`, `SCROLL_COOLDOWN_MS` | How far you move the hand per scroll step, and the pause between steps. |
| `INVERT_SCROLL` | Flip the scroll direction. |
| `STABLE_FRAMES` | Frames a gesture must hold before it counts. Raise it if gestures misfire. |

## Limitations

- The screen must stay on. Android stops camera access when the phone locks.
  Set a long screen timeout, or turn on "Stay awake" in Developer options while charging.
- Rotating the phone while hand control is running is not supported; stop and start it again.
- Banking, password and other secure screens may ignore injected touches or hide overlays.
- Lighting matters: a lit hand against a plain background tracks best.
- If you deny the notification permission, hand control still works; its notification is just hidden.

## How it works

```
front camera (CameraX)
  -> rotate + mirror frame
  -> MediaPipe HandLandmarker (21 hand points)          GestureService.kt
  -> GestureEngine: pose detection, smoothing, taps/drags/scroll/hold   GestureEngine.kt
  -> ControlAccessibilityService: dispatchGesture, Back, Home, cursor   ControlAccessibilityService.kt
```

The cursor follows your index knuckle rather than the fingertip, so closing your fingers to
pinch does not move the cursor off target.
